# webui.py - Multi-user version with session management

import logging
import asyncio
import os
import base64
import json
from typing import Dict, List, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn
from contextlib import asynccontextmanager

from dotenv import load_dotenv
load_dotenv()

from src.utils import utils
from src.utils.utils import MissingAPIKeyError
from src.agent.custom_agent import CustomAgent
from src.agent.custom_agent import logger as agent_logger 
from src.browser.custom_browser import CustomBrowser
from src.browser.custom_context import BrowserContextConfig
from src.controller.custom_controller import CustomController
from src.agent.custom_prompts import CustomSystemPrompt, CustomAgentMessagePrompt
from browser_use.browser.browser import BrowserConfig
from browser_use.browser.context import BrowserContextWindowSize
from src.session import SessionManager, UserSession

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global session manager
session_manager: SessionManager = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle"""
    global session_manager
    
    # Startup
    max_sessions = int(os.getenv("MAX_CONCURRENT_SESSIONS", "10"))
    timeout_minutes = int(os.getenv("SESSION_TIMEOUT_MINUTES", "30"))
    
    session_manager = SessionManager(
        session_timeout_minutes=timeout_minutes,
        max_sessions=max_sessions
    )
    logger.info(f"Session manager started - Max sessions: {max_sessions}, Timeout: {timeout_minutes}min")
    
    yield
    
    # Shutdown
    if session_manager:
        await session_manager.shutdown()
    logger.info("Application shutdown complete")

app = FastAPI(lifespan=lifespan)

# Mount the 'static' directory to serve HTML, CSS, JS files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Request/Response Models
class CreateSessionRequest(BaseModel):
    """Request model for creating a session"""
    pass

class CreateSessionResponse(BaseModel):
    """Response model for session creation"""
    session_id: str
    status: str

class AgentRunRequest(BaseModel):
    """Request model for running an agent"""
    session_id: str
    task: str
    llm_provider: str = "google"  # Required: openai, google, anthropic, deepseek, etc.
    llm_model_name: str | None = None  # Optional: if not provided, uses default for provider
    llm_temperature: float = 0.6
    llm_base_url: str | None = None  # Optional: custom endpoint URL
    llm_api_key: str | None = None  # Optional: if not provided, uses environment variable

class AgentRunResponse(BaseModel):
    """Response model for agent run"""
    status: str
    session_id: str
    task: str | None = None

class SessionInfoResponse(BaseModel):
    """Response model for session information"""
    session_id: str
    created_at: str
    last_activity: str
    has_browser: bool
    has_context: bool
    has_agent: bool
    task_running: bool
    websocket_count: int

class HealthResponse(BaseModel):
    """Response model for health check"""
    status: str
    active_sessions: int
    max_sessions: int

async def send_socket_message_to_session(session: UserSession, message: dict):
    """Helper to send a JSON message to all WebSockets in a session."""
    dead_sockets = []
    for websocket in session.websockets:
        try:
            await websocket.send_text(json.dumps(message))
        except Exception:
            dead_sockets.append(websocket)
    
    # Remove dead sockets
    for ws in dead_sockets:
        session.websockets.remove(ws)

async def run_agent_logic(config: AgentRunRequest, session: UserSession):
    """Run agent logic for a specific session"""
    original_info_handler = agent_logger.info
    
    try:
        # Define the function that will send logs to the websocket
        def log_to_socket(msg, *args, **kwargs):
            try:
                log_message = msg % args if args else str(msg)
                asyncio.create_task(send_socket_message_to_session(session, {"type": "log", "data": log_message}))
            except Exception as e:
                # If formatting fails, send the raw message
                asyncio.create_task(send_socket_message_to_session(session, {"type": "log", "data": str(msg)}))

        # Monkey-patch the logger for this session
        agent_logger.info = log_to_socket

        # Validate API key
        env_var_name = f"{config.llm_provider.upper()}_API_KEY"
        llm_api_key = config.llm_api_key or os.getenv(env_var_name)
        
        if not llm_api_key:
            raise MissingAPIKeyError(provider=config.llm_provider, env_var=env_var_name)

        model_name = config.llm_model_name or utils.model_names.get(config.llm_provider, [""])[0]

        # Initialize LLM
        llm = utils.get_llm_model(
            provider=config.llm_provider, 
            model_name=model_name,
            temperature=config.llm_temperature, 
            base_url=config.llm_base_url, 
            api_key=llm_api_key
        )
        
        await send_socket_message_to_session(session, {"type": "log", "data": "Browser starting..."})
        
        # Create browser for this session
        session.browser = CustomBrowser(config=BrowserConfig(headless=False))
        session.browser_context = await session.browser.new_context(
            config=BrowserContextConfig(
                no_viewport=False, 
                browser_window_size=BrowserContextWindowSize(width=1280, height=720)
            )
        )

        # Create agent for this session
        session.agent = CustomAgent(
            task=config.task, 
            llm=llm, 
            browser=session.browser, 
            browser_context=session.browser_context,
            controller=CustomController(), 
            system_prompt_class=CustomSystemPrompt,
            agent_prompt_class=CustomAgentMessagePrompt
        )
        
        agent_logger.info(f"Agent starting for task: {config.task}")
        history = await session.agent.run(max_steps=int(os.getenv("MAX_STEPS_PER_TASK", "100")))
        
        final_result = history.final_result()
        await send_socket_message_to_session(session, {"type": "result", "data": final_result})
        logger.info(f"✅ Agent finished for session {session.session_id}. Final result: {final_result}")

    except Exception as e:
        logger.error(f"Error in agent execution for session {session.session_id}: {e}", exc_info=True)
        await send_socket_message_to_session(session, {"type": "error", "data": str(e)})
    finally:
        # Restore the original logger function
        agent_logger.info = original_info_handler
        
        await send_socket_message_to_session(session, {"type": "log", "data": "Agent execution completed."})
        logger.info(f"Agent execution completed for session {session.session_id}")

async def stream_browser_view(session: UserSession):
    """Periodically captures and sends screenshots for a specific session."""
    while (session.current_task and not session.current_task.done() and 
           session.browser_context and session.browser):
        try:
            if hasattr(session.browser_context, 'browser') and session.browser_context.browser:
                playwright_browser = session.browser_context.browser.playwright_browser
                if playwright_browser and playwright_browser.contexts:
                    pw_context = playwright_browser.contexts[0]
                    if pw_context and pw_context.pages:
                        page = next((p for p in reversed(pw_context.pages) if p.url != "about:blank"), None)
                        if page and not page.is_closed():
                            screenshot_bytes = await page.screenshot(type="jpeg", quality=70)
                            b64_img = base64.b64encode(screenshot_bytes).decode('utf-8')
                            await send_socket_message_to_session(session, {"type": "stream", "data": b64_img})
        except Exception as e:
            logger.debug(f"Screenshot capture failed for session {session.session_id}: {e}")
        
        await asyncio.sleep(0.5)

# --- API Endpoints ---
@app.get("/", response_class=FileResponse)
async def read_index():
    """Serve the main HTML page"""
    return FileResponse('static/index.html')

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        active_sessions=session_manager.get_session_count(),
        max_sessions=session_manager.max_sessions
    )

@app.get("/api/providers", response_class=JSONResponse)
async def get_providers():
    """Get available LLM providers"""
    return utils.PROVIDER_DISPLAY_NAMES

@app.post("/api/session/create", response_model=CreateSessionResponse)
async def create_session(request: CreateSessionRequest = CreateSessionRequest()):
    """Create a new user session"""
    try:
        session_id = session_manager.create_session()
        return CreateSessionResponse(session_id=session_id, status="Session created successfully")
    except Exception as e:
        logger.error(f"Failed to create session: {e}")
        raise HTTPException(status_code=503, detail=f"Could not create session: {str(e)}")

@app.get("/api/session/{session_id}", response_model=SessionInfoResponse)
async def get_session_info(session_id: str):
    """Get information about a specific session"""
    session_info = session_manager.get_session_info(session_id)
    if not session_info:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return SessionInfoResponse(**session_info)

@app.delete("/api/session/{session_id}")
async def delete_session(session_id: str):
    """Delete a specific session"""
    success = await session_manager.delete_session(session_id)
    if success:
        return {"status": "Session deleted successfully"}
    else:
        raise HTTPException(status_code=404, detail="Session not found")

@app.post("/api/agent/run", response_model=AgentRunResponse)
async def start_agent_run(request: AgentRunRequest):
    """Start an agent run in a specific session"""
    session = session_manager.get_session(request.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if session.current_task and not session.current_task.done():
        raise HTTPException(status_code=409, detail="Agent is already running in this session")
    
    # Start agent task for this session
    session.current_task = asyncio.create_task(run_agent_logic(request, session))
    
    return AgentRunResponse(
        status="Agent started successfully", 
        session_id=session.session_id,
        task=request.task
    )

@app.post("/api/agent/stop/{session_id}")
async def stop_agent(session_id: str):
    """Stop the currently running agent in a session"""
    session = session_manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    if session.current_task and not session.current_task.done():
        session.current_task.cancel()
        try:
            await session.current_task
        except asyncio.CancelledError:
            pass
        return {"status": "Agent stopped successfully"}
    else:
        return {"status": "No agent running in this session"}

@app.websocket("/ws/stream/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """WebSocket endpoint for streaming data to a specific session"""
    session = session_manager.get_session(session_id)
    if not session:
        await websocket.close(code=4004, reason="Session not found")
        return
    
    await websocket.accept()
    session.websockets.append(websocket)
    streamer_task = None
    
    try:
        # Wait a moment for agent to potentially start
        await asyncio.sleep(1)
        
        if session.current_task and not session.current_task.done():
            streamer_task = asyncio.create_task(stream_browser_view(session))
        
        # Keep connection alive while task is running
        while session.current_task and not session.current_task.done():
            await asyncio.sleep(1)
        
        # Send final message
        await websocket.send_text(json.dumps({"type": "log", "data": "Session ended"}))

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for session {session_id}")
    except Exception as e:
        logger.error(f"WebSocket error for session {session_id}: {e}")
    finally:
        if streamer_task and not streamer_task.done():
            streamer_task.cancel()
        if websocket in session.websockets:
            session.websockets.remove(websocket)

# --- Main Execution ---
def main():
    """Main entry point"""
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "7788"))
    
    logger.info(f"Starting multi-user Browser Use API on {host}:{port}")
    uvicorn.run(app, host=host, port=port)

if __name__ == '__main__':
    main()